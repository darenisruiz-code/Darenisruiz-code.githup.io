---
name: Temporary Python tooling
description: Side effects to check when installing Python packages for one-off document processing.
---

Before adding Python packages for a temporary conversion or inspection task, check whether the repository already has a Python project. In this workspace, a package install initialized a root `uv` project and appended Nix packages to `.replit`, even though Python was only needed for one-off PDF inspection.

**Why:** Temporary tooling unexpectedly created unrequested project/configuration files and required cleanup.

**How to apply:** Prefer existing system utilities for one-off file inspection. If an XLSX reader is unavailable, use Python's standard-library `zipfile` and `xml.etree.ElementTree` to inspect only the needed worksheet cells instead of installing packages. If package installation is necessary, review repository status before and after; revert generated project scaffolding and restore `.replit` through its supported validation flow when the dependency is not part of the app.