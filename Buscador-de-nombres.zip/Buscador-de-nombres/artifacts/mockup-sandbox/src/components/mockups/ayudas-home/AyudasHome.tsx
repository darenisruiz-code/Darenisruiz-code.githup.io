import { useRef, useState, type FormEvent } from "react";
import { LoaderCircle, Search, X } from "lucide-react";

type BeneficiaryRecord = {
  fullName: string;
  identificationNumber: string;
  status: string;
  requestedPrograms: string[];
};

type LookupResponse = {
  beneficiary: BeneficiaryRecord | null;
};

type LookupState = "idle" | "loading" | "found" | "not-found" | "error";

function isLookupResponse(value: unknown): value is LookupResponse {
  if (typeof value !== "object" || value === null || !("beneficiary" in value)) {
    return false;
  }

  const { beneficiary } = value;
  return (
    beneficiary === null ||
    (typeof beneficiary === "object" &&
      beneficiary !== null &&
      "fullName" in beneficiary &&
      "identificationNumber" in beneficiary &&
      "status" in beneficiary &&
      "requestedPrograms" in beneficiary &&
      typeof beneficiary.fullName === "string" &&
      typeof beneficiary.identificationNumber === "string" &&
      typeof beneficiary.status === "string" &&
      Array.isArray(beneficiary.requestedPrograms) &&
      beneficiary.requestedPrograms.every(
        (program) => typeof program === "string",
      ))
  );
}

export function AyudasHome() {
  const [identificationNumber, setIdentificationNumber] = useState("");
  const [lookupState, setLookupState] = useState<LookupState>("idle");
  const [beneficiary, setBeneficiary] = useState<BeneficiaryRecord | null>(null);
  const activeRequest = useRef<AbortController | null>(null);

  function handleIdentificationChange(value: string) {
    activeRequest.current?.abort();
    activeRequest.current = null;
    setIdentificationNumber(value);
    setLookupState("idle");
    setBeneficiary(null);
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const searchValue = identificationNumber.trim();
    if (!searchValue) {
      return;
    }

    activeRequest.current?.abort();
    const controller = new AbortController();
    activeRequest.current = controller;
    setLookupState("loading");
    setBeneficiary(null);

    try {
      const response = await fetch("/api/beneficiaries/lookup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identificationNumber: searchValue }),
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new Error("Lookup request failed");
      }

      const result: unknown = await response.json();
      if (!isLookupResponse(result)) {
        throw new Error("Lookup response was invalid");
      }

      if (controller.signal.aborted) {
        return;
      }

      setBeneficiary(result.beneficiary);
      setLookupState(result.beneficiary ? "found" : "not-found");
    } catch (error) {
      if (controller.signal.aborted) {
        return;
      }

      setLookupState("error");
    }
  }

  return (
    <main className="min-h-screen bg-[#f5f4ee] font-['DM_Sans'] text-[#193c3a] selection:bg-[#d9e8b0]">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,500;9..144,600&display=swap');
        html { scroll-behavior: smooth; }
      `}</style>

      <section className="mx-auto flex min-h-[72vh] max-w-[1120px] flex-col items-center px-5 pb-16 pt-14 text-center sm:px-8 sm:pt-20 lg:px-12 lg:pt-24">
        <h1 className="max-w-[950px] font-['Fraunces'] text-[clamp(2.75rem,7vw,5.6rem)] leading-[.99] tracking-[-.055em] text-[#173b39]">
          Ayudas económicas{" "}
          <span className="text-[#6b8168]">nacionales</span> e internacionales
        </h1>
        <img
          src="/__mockup/images/ayudas-logo.jpg"
          alt="Logotipo de ayudas económicas"
          className="mt-8 h-32 w-32 rounded-2xl object-contain shadow-[0_18px_36px_-22px_rgba(0,0,0,.55)] sm:h-40 sm:w-40"
        />
        <div id="nombres" className="mt-8 w-full max-w-[620px]">
          <form onSubmit={handleSubmit}>
            <label htmlFor="identification-number" className="sr-only">
              Número de identificación
            </label>
            <div className="relative flex items-center">
              <Search
                aria-hidden="true"
                size={18}
                className="pointer-events-none absolute left-4 text-[#7b8b80]"
              />
              <input
                id="identification-number"
                type="text"
                value={identificationNumber}
                onChange={(event) =>
                  handleIdentificationChange(event.target.value)
                }
                placeholder="Ingresa tu número de identificación"
                autoComplete="off"
                autoCapitalize="characters"
                maxLength={64}
                className="min-h-14 w-full rounded-2xl border border-[#d4ddd0] bg-white py-3 pl-12 pr-32 text-left text-[14px] text-[#244842] outline-none transition placeholder:text-[#98a198] focus:border-[#7b967f] focus:ring-4 focus:ring-[#dce8bd]/60"
              />
              {identificationNumber && (
                <button
                  type="button"
                  onClick={() => handleIdentificationChange("")}
                  aria-label="Limpiar búsqueda"
                  className="absolute right-[6.75rem] flex h-9 w-9 items-center justify-center rounded-full text-[#718179] transition hover:bg-[#edf0e8] hover:text-[#244842] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7b967f]"
                >
                  <X size={17} />
                </button>
              )}
              <button
                type="submit"
                disabled={!identificationNumber.trim() || lookupState === "loading"}
                className="absolute right-1.5 flex min-h-11 items-center justify-center rounded-xl bg-[#193c3a] px-4 text-[13px] font-semibold text-white transition hover:bg-[#28524c] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7b967f] focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {lookupState === "loading" ? "Consultando" : "Consultar"}
              </button>
            </div>
            <p className="mt-3 text-left text-[12px] leading-relaxed text-[#718179]">
              Consulta con el documento usado en tu preinscripción.
            </p>
          </form>
        </div>
      </section>

      {lookupState !== "idle" && (
        <section
          id="search-results"
          className="bg-[#faf9f4]"
          aria-labelledby="search-results-heading"
          aria-live="polite"
        >
          <div className="mx-auto max-w-[1120px] px-5 py-10 sm:px-8 sm:py-12 lg:px-12">
            <span className="text-[11px] font-bold uppercase tracking-[.16em] text-[#7d8d69]">
              Consulta de beneficiarios
            </span>
            <h2
              id="search-results-heading"
              className="mt-2 font-['Fraunces'] text-3xl leading-tight tracking-[-.04em] text-[#193c3a] sm:text-4xl"
            >
              Resultado de búsqueda
            </h2>

            {lookupState === "loading" && (
              <div
                role="status"
                className="mt-6 flex items-center gap-3 rounded-2xl border border-[#e0e5dc] bg-white px-5 py-5 text-[14px] text-[#52705e]"
              >
                <LoaderCircle aria-hidden="true" size={18} className="animate-spin" />
                Consultando el registro…
              </div>
            )}

            {lookupState === "found" && beneficiary && (
              <article className="mt-6 rounded-2xl border border-[#d4ddd0] bg-white p-5 shadow-[0_18px_36px_-30px_rgba(32,62,57,.5)] sm:p-7">
                <p className="text-[12px] font-bold uppercase tracking-[.12em] text-[#718179]">
                  Registro encontrado
                </p>
                <dl className="mt-5 grid gap-5 sm:grid-cols-2">
                  <div>
                    <dt className="text-[12px] text-[#718179]">Nombre completo</dt>
                    <dd className="mt-1 text-[16px] font-semibold text-[#244842]">
                      {beneficiary.fullName}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-[12px] text-[#718179]">
                      Número de identificación
                    </dt>
                    <dd className="mt-1 text-[16px] font-semibold text-[#244842]">
                      {beneficiary.identificationNumber}
                    </dd>
                  </div>
                  <div className="sm:col-span-2">
                    <dt className="text-[12px] text-[#718179]">
                      {beneficiary.requestedPrograms.length > 1
                        ? "Programas solicitados"
                        : "Programa solicitado"}
                    </dt>
                    <dd>
                      {beneficiary.requestedPrograms.length > 0 ? (
                        <ul className="mt-2 flex flex-wrap gap-2">
                          {beneficiary.requestedPrograms.map((program) => (
                            <li
                              key={program}
                              className="rounded-full bg-[#edf1e8] px-3 py-1.5 text-[13px] font-medium text-[#34564c]"
                            >
                              {program}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="mt-1 text-[13px] text-[#718179]">
                          Sin información en el registro
                        </p>
                      )}
                    </dd>
                  </div>
                  <div className="sm:col-span-2">
                    <dt className="text-[12px] text-[#718179]">
                      Estado del programa
                    </dt>
                    <dd className="mt-2">
                      <span className="inline-flex rounded-full bg-[#e8eedf] px-3 py-1.5 text-[13px] font-semibold text-[#34564c]">
                        {beneficiary.status}
                      </span>
                    </dd>
                  </div>
                </dl>
              </article>
            )}

            {lookupState === "not-found" && (
              <div className="mt-6 rounded-2xl border border-dashed border-[#cfd9ca] bg-white px-5 py-7">
                <p className="text-[14px] font-semibold text-[#34564c]">
                  No encontramos un registro con ese número.
                </p>
                <p className="mt-2 text-[12px] text-[#718179]">
                  Verifica el documento y vuelve a intentarlo.
                </p>
              </div>
            )}

            {lookupState === "error" && (
              <div
                role="alert"
                className="mt-6 rounded-2xl border border-[#e5d8c9] bg-white px-5 py-7"
              >
                <p className="text-[14px] font-semibold text-[#6b4f3e]">
                  No pudimos realizar la consulta.
                </p>
                <p className="mt-2 text-[12px] text-[#718179]">
                  Inténtalo de nuevo más tarde.
                </p>
              </div>
            )}
          </div>
        </section>
      )}
    </main>
  );
}