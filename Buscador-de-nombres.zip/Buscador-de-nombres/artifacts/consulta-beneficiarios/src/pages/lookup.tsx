import { useState, type FormEvent } from 'react';
import { useHealthCheck, useLookupBeneficiary, getHealthCheckQueryKey } from '@workspace/api-client-react';
import { AlertCircle, ArrowRight, Check, CircleHelp, FileSearch, LoaderCircle, ShieldCheck } from 'lucide-react';
import beneficiaryLogo from '@assets/FB_IMG_1790871798979_1790871820119.jpg';

export default function LookupPage() {
  const [identificationNumber, setIdentificationNumber] = useState('');
  const [validationMessage, setValidationMessage] = useState('');
  const lookup = useLookupBeneficiary();
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey() } });
  const beneficiary = lookup.data?.beneficiary;

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const exactNumber = identificationNumber.trim();

    if (!exactNumber) {
      setValidationMessage('Escribe tu número de documento para continuar.');
      return;
    }
    if (exactNumber.length > 64) {
      setValidationMessage('El número de documento debe tener 64 caracteres o menos.');
      return;
    }

    setValidationMessage('');
    lookup.mutate({ data: { identificationNumber: exactNumber } });
  }

  function handleInputChange(value: string) {
    setIdentificationNumber(value);
    if (validationMessage) setValidationMessage('');
    if (lookup.data || lookup.isError) lookup.reset();
  }

  return (
    <main className="min-h-[100dvh]">
      <div className="page-shell">
        <header className="topbar" data-testid="header-public-service">
          <div className="brand-mark" data-testid="text-service-name">
            <img
              className="brand-logo"
              src={beneficiaryLogo}
              alt="Logo"
              data-testid="img-service-logo"
            />
            <span className="brand-label text-[13px] font-semibold tracking-[.015em]">Ayudas económicas Nal e Intl</span>
          </div>
          <span className="eyebrow !text-[9px] !tracking-[.13em]" data-testid="text-service-type">Consulta segura</span>
        </header>

        <section className="hero-grid" aria-labelledby="page-title">
          <div className="hero-copy">
            <div className="eyebrow" data-testid="text-page-kicker">Consulta de preinscripción</div>
            <h1 id="page-title" className="hero-title" data-testid="heading-lookup">
              <em>Unidos</em> por los más necesitados de todo el mundo.
            </h1>
            <p className="hero-description" data-testid="text-introduction">
              Comprueba si tu documento coincide con un registro de preinscripción. La consulta es exacta y muestra únicamente la información asociada a ese registro.
            </p>
            <div className="service-note" data-testid="text-privacy-note">
              <ShieldCheck size={17} strokeWidth={1.7} aria-hidden="true" />
              <span>Usamos tu número solo para buscar una coincidencia. No compartas datos de otras personas.</span>
            </div>
          </div>

          <section className="form-card" aria-labelledby="lookup-title" data-testid="card-lookup">
            <div className="card-kicker">Servicio de consulta</div>
            <h2 className="card-title" id="lookup-title">Consulta aquí si eres beneficiario</h2>
            <p className="card-description">Ingresa el número tal como aparece en tu documento de identidad.</p>

            <form onSubmit={handleSubmit} noValidate data-testid="form-lookup">
              <label className="lookup-label" htmlFor="identification-number">Número de documento</label>
              <div className="lookup-row">
                <input
                  id="identification-number"
                  name="identificationNumber"
                  className="lookup-input"
                  type="text"
                  value={identificationNumber}
                  onChange={(event) => handleInputChange(event.target.value)}
                  placeholder="Escribe tu número"
                  autoComplete="off"
                  maxLength={64}
                  aria-invalid={Boolean(validationMessage)}
                  aria-describedby="lookup-hint"
                  data-testid="input-identification-number"
                />
                <button className="lookup-button" type="submit" disabled={lookup.isPending} data-testid="button-submit-lookup">
                  {lookup.isPending ? (
                    <><LoaderCircle size={16} className="animate-spin" aria-hidden="true" /> Buscando</>
                  ) : (
                    <>Consultar <ArrowRight size={16} aria-hidden="true" /></>
                  )}
                </button>
              </div>
              <p className="form-hint" id="lookup-hint">La búsqueda distingue cada documento; revisa que no falte ningún número.</p>
              {validationMessage && (
                <div className="validation-message" role="alert" data-testid="status-validation-error">
                  <AlertCircle size={16} aria-hidden="true" />
                  <span>{validationMessage}</span>
                </div>
              )}
              {lookup.isError && (
                <div className="error-message" role="alert" data-testid="status-network-error">
                  <span className="flex items-start gap-2">
                    <AlertCircle size={16} className="mt-[1px] flex-none" aria-hidden="true" />
                    <span>No pudimos completar la consulta. Revisa tu conexión e inténtalo de nuevo.</span>
                  </span>
                  <button type="submit" className="retry-button" data-testid="button-retry-lookup">Reintentar</button>
                </div>
              )}
            </form>

            {lookup.isPending && (
              <div className="loading-result" aria-live="polite" data-testid="status-lookup-loading">
                <div className="skeleton short" />
                <div className="skeleton" />
                <div className="skeleton" />
                <span className="sr-only">Buscando coincidencia exacta…</span>
              </div>
            )}

            {lookup.isSuccess && beneficiary && (
              <section className="result-panel" aria-live="polite" aria-labelledby="match-title" data-testid="result-match">
                <div className="result-header">
                  <span className="result-icon" aria-hidden="true"><Check size={16} strokeWidth={2.2} /></span>
                  <div>
                    <h3 className="result-heading" id="match-title">Encontramos una coincidencia</h3>
                    <p className="result-subhead">Este documento coincide con un registro de preinscripción.</p>
                  </div>
                </div>
                <dl className="record-list">
                  <div className="record-item" data-testid="record-full-name">
                    <dt>Nombre completo</dt>
                    <dd>{beneficiary.fullName}</dd>
                  </div>
                  <div className="record-item" data-testid="record-identification-number">
                    <dt>Número de documento</dt>
                    <dd>{beneficiary.identificationNumber}</dd>
                  </div>
                  <div className="record-item" data-testid="record-status">
                    <dt>Estado del registro</dt>
                    <dd>{beneficiary.status}</dd>
                  </div>
                  {beneficiary.suspensionReason && (
                    <div className="record-item" data-testid="record-suspension-reason">
                      <dt>Motivo de suspensión</dt>
                      <dd>{beneficiary.suspensionReason}</dd>
                    </div>
                  )}
                  <div className="record-item" data-testid="record-requested-programs">
                    <dt>{beneficiary.requestedPrograms.length === 1 ? 'Programa solicitado' : 'Programas solicitados'}</dt>
                    <dd>
                      {beneficiary.requestedPrograms.length ? (
                        <ul className="program-list">
                          {beneficiary.requestedPrograms.map((program, index) => (
                            <li key={`${program}-${index}`} data-testid={`text-requested-program-${index}`}>{program}</li>
                          ))}
                        </ul>
                      ) : 'No se muestran programas solicitados en este registro.'}
                    </dd>
                  </div>
                </dl>
                <p className="notice" data-testid="notice-pre-registration">
                  Un programa solicitado en la preinscripción no confirma la inscripción ni la aprobación de un beneficio.
                </p>
              </section>
            )}

            {lookup.isSuccess && !beneficiary && (
              <section className="result-panel" aria-live="polite" aria-labelledby="not-found-title" data-testid="result-not-found">
                <div className="empty-result">
                  <FileSearch size={20} strokeWidth={1.7} aria-hidden="true" />
                  <div>
                    <strong id="not-found-title">No encontramos una coincidencia</strong>
                    <p>Verifica que el número esté escrito exactamente como aparece en tu documento. Si está correcto, puede que no exista un registro de preinscripción asociado.</p>
                  </div>
                </div>
              </section>
            )}
          </section>
        </section>

        <aside className="trust-band" data-testid="panel-important-information">
          <div className="trust-copy">
            <strong>Una consulta informativa, no una decisión.</strong>
            <p>Este resultado solo indica si encontramos un registro con el documento ingresado. La preinscripción de un programa no confirma inscripción, aprobación ni acceso a beneficios.</p>
          </div>
          <span className="trust-stamp" aria-hidden="true"><CircleHelp size={25} strokeWidth={1.35} /></span>
        </aside>

        <footer className="footer" data-testid="footer-service">
          <span>Servicio público de consulta · Información confidencial</span>
          <span className="health-indicator" data-testid="status-service-availability" aria-live="polite">
            <i className={`health-dot${health.isError ? ' offline' : ''}`} />
            {health.isLoading ? 'Conexión del servicio' : health.isError ? 'Servicio temporalmente no disponible' : 'Servicio disponible'}
          </span>
        </footer>
      </div>
    </main>
  );
}