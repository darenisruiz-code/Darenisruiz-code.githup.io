import { Router, type IRouter } from "express";
import beneficiariesRouter from "./beneficiaries";
import healthRouter from "./health";

const router: IRouter = Router();

router.use(beneficiariesRouter);
router.use(healthRouter);

export default router;
