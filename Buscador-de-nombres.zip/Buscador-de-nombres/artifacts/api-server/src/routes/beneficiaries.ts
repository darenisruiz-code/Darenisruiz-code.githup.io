import { Router, type IRouter } from "express";
import {
  LookupBeneficiaryBody,
  LookupBeneficiaryResponse,
} from "@workspace/api-zod";
import { lookupBeneficiary } from "../lib/beneficiaryLookup";

const router: IRouter = Router();

router.post("/beneficiaries/lookup", (req, res): void => {
  const parsed = LookupBeneficiaryBody.safeParse(req.body);
  if (!parsed.success || !parsed.data.identificationNumber.trim()) {
    res.status(400).set("Cache-Control", "no-store").json({
      error: "Ingresa un número de identificación válido.",
    });
    return;
  }

  const beneficiary = lookupBeneficiary(parsed.data.identificationNumber);
  const response = LookupBeneficiaryResponse.parse({ beneficiary });

  res.set("Cache-Control", "no-store").json(response);
});

export default router;