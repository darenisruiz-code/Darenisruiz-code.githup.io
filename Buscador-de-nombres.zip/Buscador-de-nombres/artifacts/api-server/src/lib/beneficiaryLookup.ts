import registry from "../data/beneficiaries.json";
import type { BeneficiaryRecord } from "@workspace/api-zod";

const registryByIdentification = new Map<string, BeneficiaryRecord>();

function normalizeIdentification(value: string): string {
  const normalized = value
    .trim()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase();
  const withoutNumericDecimalSuffix = normalized.replace(/^(\d+)\.0+$/, "$1");

  return withoutNumericDecimalSuffix.replace(/[^A-Z0-9]/g, "");
}

for (const beneficiary of registry) {
  const key = normalizeIdentification(beneficiary.identificationNumber);
  if (key) {
    registryByIdentification.set(key, beneficiary);
  }
}

export function lookupBeneficiary(identificationNumber: string): BeneficiaryRecord | null {
  const key = normalizeIdentification(identificationNumber);
  if (!key) {
    return null;
  }

  return registryByIdentification.get(key) ?? null;
}