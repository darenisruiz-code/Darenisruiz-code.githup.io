import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowUpRight, Search, X } from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type NameEntry = {
  name: string;
  origin: string;
  meaning: string;
  note: string;
};

const nameCollection: NameEntry[] = [
  { name: 'Alba', origin: 'Latín', meaning: 'amanecer, primera luz', note: 'Breve y luminosa, como empezar de nuevo.' },
  { name: 'Amalia', origin: 'Germánico', meaning: 'trabajo, esfuerzo', note: 'Un clásico suave con mucha personalidad.' },
  { name: 'Bruno', origin: 'Germánico', meaning: 'oscuro, moreno', note: 'Sereno, rotundo y fácil de recordar.' },
  { name: 'Clara', origin: 'Latín', meaning: 'brillante, clara', note: 'Un nombre de siempre que nunca pierde luz.' },
  { name: 'Elena', origin: 'Griego', meaning: 'antorcha, resplandor', note: 'Musical y elegante en cualquier idioma.' },
  { name: 'Gael', origin: 'Celta', meaning: 'de origen gaélico', note: 'Corto, cálido y con aire aventurero.' },
  { name: 'Inés', origin: 'Griego', meaning: 'pura, casta', note: 'Pequeño nombre, gran presencia.' },
  { name: 'Leo', origin: 'Latín', meaning: 'león', note: 'Directo y valiente, sin una sílaba de más.' },
  { name: 'Lucía', origin: 'Latín', meaning: 'luz', note: 'De esos nombres que suenan a mañana.' },
  { name: 'Mateo', origin: 'Hebreo', meaning: 'regalo de Dios', note: 'Cercano, redondo y lleno de historia.' },
  { name: 'Nora', origin: 'Árabe / irlandés', meaning: 'luz, honor', note: 'Delicado sin dejar de ser decidido.' },
  { name: 'Olivia', origin: 'Latín', meaning: 'olivo, símbolo de paz', note: 'Clásica, dulce y un poco cosmopolita.' },
  { name: 'Sofía', origin: 'Griego', meaning: 'sabiduría', note: 'Un nombre viajero que se siente de casa.' },
  { name: 'Teo', origin: 'Griego', meaning: 'Dios', note: 'Sencillo, luminoso y con ritmo propio.' },
  { name: 'Vera', origin: 'Eslavo / latín', meaning: 'fe, verdad', note: 'Una palabra bonita que también es nombre.' },
  { name: 'Violeta', origin: 'Latín', meaning: 'flor violeta', note: 'Un toque poético, sin perder frescura.' },
];

const suggestions = ['Alba', 'Mateo', 'Lucía', 'Nora'];

function normalize(value: string) {
  return value.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLocaleLowerCase('es');
}

function Home() {
  const [query, setQuery] = useState('');
  const searchRef = useRef<HTMLInputElement>(null);
  const filteredNames = useMemo(() => {
    const normalizedQuery = normalize(query.trim());
    if (!normalizedQuery) return nameCollection;
    return nameCollection.filter(({ name, origin, meaning, note }) =>
      normalize(`${name} ${origin} ${meaning} ${note}`).includes(normalizedQuery),
    );
  }, [query]);

  useEffect(() => {
    const focusSearch = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        searchRef.current?.focus();
      }
    };
    window.addEventListener('keydown', focusSearch);
    return () => window.removeEventListener('keydown', focusSearch);
  }, []);

  return (
    <main className="page-shell">
      <div className="page-content mx-auto max-w-[1120px] px-5 pb-16 sm:px-8 lg:px-12">
        <header className="flex items-center justify-between border-b border-foreground/10 py-6 sm:py-7" data-testid="header-site">
          <div className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-full bg-foreground text-background" aria-hidden="true">
              <span className="serif text-[25px] leading-none">n</span>
            </span>
            <div>
              <p className="text-[12px] font-bold tracking-[0.16em] uppercase">Nombres con calma</p>
              <p className="mono mt-0.5 text-[9px] tracking-[0.12em] text-foreground/55 uppercase">Un pequeño cuaderno</p>
            </div>
          </div>
          <span className="mono hidden text-[10px] tracking-[0.13em] text-foreground/45 uppercase sm:block">Selección 01 · en español</span>
          <span className="mono text-[10px] text-foreground/50 sm:hidden">01 / 16</span>
        </header>

        <section className="relative pb-12 pt-14 sm:pb-16 sm:pt-[76px]" aria-labelledby="hero-title">
          <div className="absolute right-0 top-[62px] hidden select-none text-[210px] leading-none text-accent/25 sm:block" aria-hidden="true">
            <span className="serif italic">á</span>
          </div>
          <p className="mono mb-5 flex items-center gap-2 text-[10px] tracking-[0.17em] text-foreground/55 uppercase">
            <span className="h-px w-7 bg-accent" />
            Para encontrar ese nombre
          </p>
          <h1 id="hero-title" className="serif max-w-[730px] text-[clamp(3.55rem,9vw,7rem)] leading-[0.91] tracking-[-0.035em]">
            Un nombre puede ser <span className="text-accent italic">el primer regalo.</span>
          </h1>
          <p className="mt-6 max-w-[430px] text-[15px] leading-7 text-foreground/65 sm:text-[16px]">
            Una lista breve, bonita y llena de historias. Busca por nombre, origen o significado; las tildes no son un obstáculo.
          </p>

          <div className="relative mt-9 max-w-[650px]">
            <label htmlFor="name-search" className="sr-only">Buscar nombres, orígenes o significados</label>
            <div className="search-focus flex h-[62px] items-center gap-3 rounded-[18px] border border-foreground/15 bg-card px-4 shadow-sm sm:h-[68px] sm:px-5">
              <Search className="size-[19px] shrink-0 text-foreground/50" strokeWidth={1.8} aria-hidden="true" />
              <input
                ref={searchRef}
                id="name-search"
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Prueba con “Lucia” o “luz”…"
                autoComplete="off"
                className="h-full min-w-0 flex-1 border-0 bg-transparent text-[15px] text-foreground outline-none placeholder:text-foreground/40 sm:text-[16px]"
                data-testid="input-name-search"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery('')}
                  aria-label="Limpiar búsqueda"
                  className="grid size-9 shrink-0 place-items-center rounded-full text-foreground/55 transition-colors hover:bg-foreground/5 hover:text-foreground focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                  data-testid="button-clear-search"
                >
                  <X className="size-4" aria-hidden="true" />
                </button>
              )}
              <span className="mono hidden rounded-md border border-foreground/10 px-2 py-1 text-[10px] text-foreground/40 sm:block">⌘ K</span>
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-2" data-testid="group-search-suggestions">
              <span className="mr-1 text-[11px] text-foreground/50">Empieza por</span>
              {suggestions.map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => setQuery(suggestion)}
                  className="quick-chip rounded-full border border-foreground/12 bg-transparent px-3 py-1.5 text-[11px] text-foreground/70 hover:border-foreground/30 hover:bg-card"
                  data-testid={`button-suggestion-${normalize(suggestion)}`}
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        </section>

        <section className="border-t border-foreground/12 pt-7" aria-labelledby="results-heading">
          <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="mono mb-2 text-[9px] tracking-[0.16em] text-foreground/45 uppercase">El índice</p>
              <h2 id="results-heading" className="serif text-[34px] leading-none sm:text-[40px]">
                {query ? 'Lo que encontramos' : 'Una pequeña selección'}
              </h2>
            </div>
            <p className="mono pb-1 text-[10px] tracking-[0.08em] text-foreground/50" data-testid="text-results-count" aria-live="polite">
              {filteredNames.length.toString().padStart(2, '0')} {filteredNames.length === 1 ? 'NOMBRE' : 'NOMBRES'}
            </p>
          </div>

          {filteredNames.length > 0 ? (
            <div className="grid grid-cols-1 gap-x-8 sm:grid-cols-2" data-testid="list-name-results">
              {filteredNames.map((entry, index) => (
                <article
                  key={entry.name}
                  className="name-item group flex min-h-[134px] items-start justify-between gap-4 border-t border-foreground/12 py-5"
                  style={{ animationDelay: `${Math.min(index, 8) * 35}ms` }}
                  data-testid={`card-name-${normalize(entry.name)}`}
                >
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-baseline gap-x-2.5 gap-y-1">
                      <h3 className="serif text-[29px] leading-none tracking-[-0.02em]">{entry.name}</h3>
                      <span className="mono text-[9px] tracking-[0.08em] text-foreground/45 uppercase">{entry.origin}</span>
                    </div>
                    <p className="mt-2 text-[12px] text-accent/95">{entry.meaning}</p>
                    <p className="mt-2 max-w-[330px] text-[12px] leading-[1.6] text-foreground/58">{entry.note}</p>
                  </div>
                  <ArrowUpRight className="name-arrow mt-0.5 size-4 shrink-0 text-foreground/30 group-hover:text-accent" strokeWidth={1.6} aria-hidden="true" />
                </article>
              ))}
            </div>
          ) : (
            <div className="border-y border-foreground/12 py-12 text-center" data-testid="empty-search-state">
              <span className="serif text-5xl italic text-accent/80" aria-hidden="true">¿Y si…?</span>
              <h3 className="mt-3 text-[15px] font-semibold">Todavía no tenemos ese nombre.</h3>
              <p className="mx-auto mt-2 max-w-sm text-[13px] leading-6 text-foreground/55">
                Prueba otra búsqueda o borra el texto para volver a recorrer la selección.
              </p>
              <button
                type="button"
                onClick={() => setQuery('')}
                className="mt-5 rounded-full bg-foreground px-4 py-2.5 text-[12px] font-medium text-background transition-transform hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                data-testid="button-reset-search"
              >
                Ver todos los nombres
              </button>
            </div>
          )}
        </section>

        <footer className="mt-12 flex flex-col gap-3 border-t border-foreground/12 pt-5 text-[11px] text-foreground/45 sm:flex-row sm:items-center sm:justify-between" data-testid="footer-site">
          <p>Hecho para leer despacio y encontrar sin prisa.</p>
          <p className="mono text-[9px] tracking-[0.12em] uppercase">16 nombres · cada uno, una historia</p>
        </footer>
      </div>
    </main>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
